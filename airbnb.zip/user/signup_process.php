<?php
		include 'config.php';
		
        // 1. UI: GET the information from the form
        $email = $_POST["email"];
        $password = $_POST["password"];
		$fname = $_POST["fname"];
        $lname = $_POST["lname"];
		//echo n;
		//echo i;
		
      	// SQL QUERY:
       $sql  =   "INSERT INTO user_data (email,password,fname,lname) 
		VALUES "
            . '("'
            . $email
            . '","'
            . $password
            . '","'
            . $fname
            . '","'
            . $lname
            . '")';

        //echo "Query you are sending to db: " . $query  . "<br>";
	$results = mysqli_query($conn, $sql);

       
		header('location:index.php');
		
	

?>