<?php
 include 'config.php';
include 'header.php';

$amount = $_POST["total"];
 $nights = $_POST["nights"];
 $guests = $_POST["guests"];
 $room_id = $_POST["room_id"];
 $email = $_SESSION['email'];
 $phone = $_POST["phone"];
 $cc = $_POST["cc"];

        for ($i = 0; $i <16; $i=$i+2)
		 {
          // double the number
          $x = $cc[$i]*2;

          // check if its > 9, if yes, then convert
          if ($x > 9) {
            $x = $x - 9;
          }

          // update the number
          $cc[$i] = $x;
          echo $cc[$i] . "<br>";
        }

        echo "========== <br>";

        // total all the numbers
        $total = 0;
        for ($j = 0; $j < 16; $j++) {
          $total = $total + $cc[$j];
        }
        echo "Answer: " . $total;
        echo "<br>";

        echo "========== <br>";

        // check if cc number is divisible by 10
        if ($total % 10 == 0) {
          echo "Its divisibble! VALID";
		  
		  $sql  =   "INSERT INTO book_data (	email,room_id,nights,	guests,amount,	phone ) 
		VALUES "
            . '("'
            . $email
            . '","'
            . $room_id
            . '","'
            . $nights
            . '","'
			. $guests
            . '","'
            . $amount
            . '","'
            . $phone
            . '")';
		  
		  $results = mysqli_query($conn, $sql);
		   
		   $Message ="Bookin Successful....!! Thank You For Booking AirBnB...";
		  header("Location:thankyou.php?Message=".$Message);
		}
        else {
		  $Message ="Sorry....!! Wrong Card Details.. Try Again...!!";
		  header("Location:thankyou.php?Message=".$Message);
        }





?>