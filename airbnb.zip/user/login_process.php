<?php
		include 'config.php';
		
        // 1. UI: GET the information from the form
        $n = $_POST["email"];
        $i = $_POST["password"];
		
		echo n;
		echo i;
		
      	// SQL QUERY:
        $query = 'SELECT * FROM user_data where email="'
                . $n
                . '" and password="'
                . $i
                . '"';

        //echo "Query you are sending to db: " . $query  . "<br>";
	$results = mysqli_query($conn, $query);

        // 3. LOGIC: check if user is in the database
        // If in db, $y = 0
        // Otherwise, $y = 1
        $y = mysqli_num_rows($results);
      //  echo "Number of rows returned: " . $y . "<br>";
	if($y == 1)
	{
		session_start();
		$id = $_SESSION['email']=$_POST['email'];
		header('location:home.php');
		
	}
	else
	{
		echo'Incorrect email or password!';
		header('location:index.php');
		}
	

?>