<!DOCTYPE html>
<html lang="en">

<head>

</head>

<body>
	<?php include 'config.php';?>
	<?php include 'header.php';?>
	  
  <!-- Primary Page Layout
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->

 <div class="container">
    <div class="row">
      <div class="one-third column wide">
        <div class="boxes">
          <div class="headerpull">
		  
		   <?php

				  $id= $_POST['id'];
				  $rating = $_POST['rating'];
				  $norv=$_POST['norv']; 
				  $price= $_POST["Price"];
				  $z= $_POST['Nights'];
				  $w= $_POST['Guests'];
				  
				  $t= $price*$z;
				  ?>
		  
          <h4>$	<?php 	echo $price;?>	per night
         </h4>
        </div>
		
		 <div class="smallContainer">
      <div class="smallImages">
          <span role="img">
           
		   <?php
		   for ($i = 1; $i <=$rating; $i++) {
		    ?> 
           
              <span class="star">
                <span>
                  <svg viewBox="0 0 1000 1000" role="presentation" aria-hidden="true" focusable="false" style="height: 10px; width: 10px; display: block; fill: currentcolor;">
                    <path d="M971.5 379.5c9 28 2 50-20 67L725.4 618.6l87 280.1c11 39-18 75-54 75-12 0-23-4-33-12l-226.1-172-226.1 172.1c-25 17-59 12-78-12-12-16-15-33-8-51l86-278.1L46.1 446.5c-21-17-28-39-19-67 8-24 29-40 52-40h280.1l87-278.1c7-23 28-39 52-39 25 0 47 17 54 41l87 276.1h280.1c23.2 0 44.2 16 52.2 40z"></path>
                  </svg>
                </span>
              </span>
			  <?php 
			}  
			  ?>
			  
            </span>
            <span style="position: absolute;"> <?php echo $norv; ?> Reviews </span>
			<br><br>
          </div>
        </div>
			<label for="exampleRecipientInput">        $<?php echo $price; ?> *   <?php echo $_POST['Nights']; ?> Nights = $<?php echo $t;?></label>
	  	  			 <label for="exampleRecipientInput">Cleaning fee  $30</label>
					 <label for="exampleRecipientInput">Service fee  $39</label>
					 <label for="exampleRecipientInput">Occupancy taxes and fees  $30</label>
					 	<?php $total= $t+30+39+30; ?>
			 <label for="exampleRecipientInput">Total: $<?php echo $total;?></label>
		
		  <form action="booking.php" method="POST">
		  
      	<input class="input" type="hidden" id="id" name="id" value="<?php echo $id; ?>">
			<input class="input" type="hidden" id="Price" name="Price" value="<?php echo $price; ?>">
				<input class="input" type="hidden" id="rating" name="rating" value="<?php echo $rating; ?>">
					<input class="input" type="hidden" id="norv" name="norv" value="<?php echo $norv; ?>">	
					<input class="input" type="hidden" id="total" name="total" value="<?php echo $total; ?>">
					<input class="input" type="hidden" id="nights" name="nights" value="<?php echo $z; ?>">	
					<input class="input" type="hidden" id="guests" name="guests" value="<?php echo $w; ?>">		
					<br>
              	<input class="button-primary" id="button" type="submit" value="confirm">
			
         		
     .   </div>    
      </div>
    </div>
  </div>
			
			</form>
		<div style="margin-top:-39px;">
         		
     .   </div>    
      </div>
    </div>
  </div>
  <!-- End Document
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
</body>

</html>
