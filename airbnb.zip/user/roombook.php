<!DOCTYPE html>
<html lang="en">

<head>
</head>

<body>
	<?php include 'config.php';?>
	<?php include 'header.php';?>
	  
  <!-- Primary Page Layout
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->

 <div class="container">
    <div class="row">
      <div class="one-third column wide">
        <div class="boxes">
          <div class="headerpull">
	    <?php
				 			if(isset($_GET['id'])){
   											// echo $_GET['id'];
											 }
				  
    							 $sql = "SELECT * FROM room_data WHERE ID = '".$id."' ";
   							$results = mysqli_query($conn, $sql);

 							$x = mysqli_fetch_assoc($results);
							$price = $x["Price"];
							$rating = $x["Rating"];
							$norv = $x["Number of Reviews"];
		   ?>
		   
		   
		   
		   
          <h4>$	<?php echo $x["Price"]; ?>	per night
         </h4>
        </div>
		
		 <div class="smallContainer">
      <div class="smallImages">
          <span role="img">
           
		   <?php 
		   $rating = $x["Rating"]; 
		   for ($i = 1; $i <=$rating; $i++) {
		    ?> 
           
              <span class="star">
                <span>
                  <svg viewBox="0 0 1000 1000" role="presentation" aria-hidden="true" focusable="false" style="height: 10px; width: 10px; display: block; fill: currentcolor;">
                    <path d="M971.5 379.5c9 28 2 50-20 67L725.4 618.6l87 280.1c11 39-18 75-54 75-12 0-23-4-33-12l-226.1-172-226.1 172.1c-25 17-59 12-78-12-12-16-15-33-8-51l86-278.1L46.1 446.5c-21-17-28-39-19-67 8-24 29-40 52-40h280.1l87-278.1c7-23 28-39 52-39 25 0 47 17 54 41l87 276.1h280.1c23.2 0 44.2 16 52.2 40z"></path>
                  </svg>
                </span>
              </span>
			  <?php 
			  }
			  ?>
			  
            </span>
            <span style="position: absolute;"> <?php echo $x["Number of Reviews"]; ?> Review </span>
          </div>
        </div>
          <form action="roombook2.php" method="POST">
		  
		     <div class="row pulldown pullright">
		     <label for="exampleRecipientInput">Nights</label>
              <select class="u-full-width" id="exampleRecipientInput"  name="Nights">
                <option value="1" name="Nights" >1 nights</option>
                <option value="2"  name="Nights">2 nights</option>
				 <option value="3"  name="Nights">3 nights</option>
                <option value="4"  name="Nights">4 nights</option>
				 <option value="5"  name="Nights">5 nights</option>
                <option value="6"  name="Nights">6 nights</option>
				 <option value="7"  name="Nights">7 nights</option>
                <option value="8"  name="Nights">8 nights</option>
				 <option value="9"  name="Nights">9 nights</option>
                <option value="10"  name="Nights">10 nights</option>
              </select>
            </div>
			
			 <div class="row pulldown pullright">
		     <label for="exampleRecipientInput">Guests</label>
              <select class="u-full-width" id="exampleRecipientInput" name="Guests">
                <option value=" 1" name="Guests">1 guests</option>
                <option value=" 1" name="Guests">2 guests</option>
				 <option  value=" 1" name="Guests">3 guests</option>
                <option value=" 1" name="Guests">4 guests</option>
				 <option  value=" 1" name="Guests">5 guests</option>
                <option  value=" 1" name="Guests">6 guests</option>
				 <option  value=" 1" name="Guests">7 guests</option>
                <option  value=" 1" name="Guests">8 guests</option>
				 <option  value=" 1" name="Guests">9 guests</option>
                <option  value=" 1" name="Guests">10 guests</option>
              </select>
            </div>
	
			<div class="row pullright">
			<input class="input" type="hidden" id="id" name="id" value="<?php echo $id; ?>">
			<input class="input" type="hidden" id="Price" name="Price" value="<?php echo $price; ?>">
				<input class="input" type="hidden" id="rating" name="rating" value="<?php echo $rating; ?>">
					<input class="input" type="hidden" id="norv" name="norv" value="<?php echo $norv; ?>">
              <input class="button-primary" id="button" type="submit" value="check total">
            </div>
			
			</form>
			 <?php
		if(isset($_GET['Message'])){
    echo $_GET['Message'];
}
?> 
		<div style="margin-top:-39px;">
             

 
  <!-- End Document
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
</body>

</html>
