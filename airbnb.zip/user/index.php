<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>AirBNB</title>
  <link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">
  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" href="css/navigation.css">
  <link rel="icon" type="image/png" href="images/airbnbfavicon.png">

  <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
</head>

<body>
	<?php include 'config.php';?>
	<?php include 'header.php';?>
<div class="container">
    <div class="row">
      <div class="one-third column wide">
        <div class="boxes">
          <div class="headerpull">
          <h4>Login</h4>
          <h6>Discover entire homes and private rooms perfect for any trip.</h6>
        </div>
          <form action="login_process.php" METHOD="POST">
		  
            <div class="row pullright">
              <div class="six columns">
                <label for="exampleEmailInput">Email</label>
                <input class="u-full-width" type="email" id="email" name= "email" placeholder="alexswam@gmail.com">
              </div>
			  </div>
			  <div class="row pullright">
              <div class="six columns">
                <label for="exampleEmailInput">Password</label>
                <input class="u-full-width" type="password"  id="exampleRecipientInput" name="password" placeholder="********" >
              </div>
            </div>
			
            <div class="row pullright">
              <input class="button-primary" id="button" type="submit" value="Login">
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
	<?php include 'footer.php';?>
 </div>
</body>

</html>
