<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>AirBNB</title>
  <link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">
  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" href="css/navigation.css">
  <link rel="icon" type="image/png" href="images/airbnbfavicon.png">

  <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
</head>

<body>
	<?php include 'config.php';?>
	<?php include 'header.php';?>
<div class="container">
    <div class="row">
      <div class="one-third column wide">
        <div class="boxes">
          <div class="headerpull">
          <h4>Start Your Search Here</h4>
          <h6>Discover entire homes and private rooms perfect for any trip.</h6>
        </div>
          <form  action="home.php" method="POST">
            <div class="row pulldown pullright">
           <input type="text" placeholder="Search..." id ="search" name="search">
            </div>
          </form>
		  <?php
		   if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. Get the data from the form url
     $search =  $_POST["search"];
	 echo "<strong> Showing Data For : </strong> ";
	 echo $search; 
// Insert data into the db
    $sql = "SELECT * FROM room_data WHERE Location = '".$search."' ";
    $results = mysqli_query($conn, $sql);
		   ?>
        </div>
      </div>
    </div>
  </div>

  <div id="container1">
    <div id="movementDown">
    <h4>What guests are saying about homes in Toronto</h4>
  </div>
    <div>
	
      <svg viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false" style="height: 20px; width: 20px; fill: rgb(255, 180, 0);position: absolute; padding-top: 2px;">
        <path d="m21.95 9.48a.84.84 0 0 0 -.87-.48h-4.62a.5.5 0 0 0 0 1l4.14.01-4.81 4.17a.5.5 0 0 0 -.14.57l2.65 6.38-6.07-3.72a.5.5 0 0 0 -.52 0l-6.08 3.72 2.65-6.37a.5.5 0 0 0 -.13-.57l-4.75-4.18h5.75a.5.5 0 0 0 .46-.3l2.37-5.37 1.58 3.57a.5.5 0 0 0 .91-.41l-1.72-3.88a.8.8 0 0 0 -1.56-.01l-2.38 5.39h-5.9a.83.83 0 0 0 -.87.48.85.85 0 0 0 .32.96l4.85 4.25-2.78 6.67a.81.81 0 0 0 .16.98.66.66 0 0 0 .43.15 1.1 1.1 0 0 0 .56-.18l6.37-3.91 6.38 3.92a.81.81 0 0 0 .99.03c.15-.12.37-.41.15-1l-2.77-6.66 4.92-4.26a.84.84 0 0 0 .31-.95zm-.78.53h-.01"
          fill="#484848"></path>
        <path d="m11 21.5a.5.5 0 1 1 -.5-.5.5.5 0 0 1 .5.5zm-3.5-15.5a.5.5 0 1 0 .5.5.5.5 0 0 0 -.5-.5zm15 10h-.5v-.5a.5.5 0 0 0 -1 0v .5h-.5a.5.5 0 0 0 0 1h .5v.5a.5.5 0 0 0 1 0v-.5h.5a.5.5 0 0 0 0-1zm-15-13h-.5v-.5a.5.5 0 0 0 -1 0v .5h-.5a.5.5 0 0 0 0 1h .5v.5a.5.5 0 0 0 1 0v-.5h.5a.5.5 0 0 0 0-1zm10.22 7.54a.84.84 0 0 0 -.17-.02q-.28-.01-3.19 0a .6.6 0 0 1 -.55-.35l-1.5-3.23a.42.42 0 0 0 -.75 0l-1.81 4.14a2.92 2.92 0 0 0 4.12 3.72l.46-.26 3.49-2.99.16-.18a.5.5 0 0 0 -.26-.82z"></path>
      </svg>
    </div>
    <div>
      <p style="padding-left: 30px;"> Toronto homes were rated
        <strong>4.6 out of 5 stars</strong> with
        <strong>200,000+ reviews</strong>
      </p>
    </div>
  </div>
  <div class="container1 borderClass" id="container4">
    <h4>Homes in India</h4>
    <div class="row">
	 <?php
 while( $x = mysqli_fetch_assoc($results) ) {
 ?>
		
      <div class="three columns contentsize" id="full-width">
	  <a href="room.php?id=<?php echo $x["ID"] ; ?>  ">
        <img src="images/image1.jpg">
        <p style="margin-bottom: 0rem;"><strong id="textSmall1"><?php echo $x["Type"] ; ?>  -  <?php echo $x["Location"] ; ?></strong><br/>
        <strong><?php echo substr($x["Name"],0,100) . "..."  ;  ?></strong><br/>
          Price  $<?php echo $x["Price"] ; ?> per night·<?php if ($x["Free Cancellation"] == "Yes") { echo" Free Cancellation";}  ?>
      </p>
      <div class="smallContainer">
      <div class="smallImages">
          <span role="img">
           
		   <?php 
		   $rating = $x["Rating"]; 
		   for ($i = 1; $i <=$rating; $i++) {
		    ?> 
           
              <span class="star">
                <span>
                  <svg viewBox="0 0 1000 1000" role="presentation" aria-hidden="true" focusable="false" style="height: 10px; width: 10px; display: block; fill: currentcolor;">
                    <path d="M971.5 379.5c9 28 2 50-20 67L725.4 618.6l87 280.1c11 39-18 75-54 75-12 0-23-4-33-12l-226.1-172-226.1 172.1c-25 17-59 12-78-12-12-16-15-33-8-51l86-278.1L46.1 446.5c-21-17-28-39-19-67 8-24 29-40 52-40h280.1l87-278.1c7-23 28-39 52-39 25 0 47 17 54 41l87 276.1h280.1c23.2 0 44.2 16 52.2 40z"></path>
                  </svg>
                </span>
              </span>
			  <?php 
			  }
			  ?>
			  
            </span>
            <span style="position: absolute;"> <?php echo $x["Number of Reviews"]; ?> Reviews . <?php if ($x["Superhost"] == "Yes") { echo"Superhost";}else{} ?>  </span>
          </div>
        </div>
		</a>
      </div>
	  <br>
   
     <?php  } ?>
  
   <div class="contentContainer">
   </div>
  </div>
  
  	<?php include 'footer.php';?>
  
    <?php } ?>
</body>

</html>
