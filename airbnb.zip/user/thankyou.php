<!DOCTYPE html>
<html lang="en">

</head>

<body>
	<?php include 'config.php';?>
	<?php include 'header.php';?>
	  
  <!-- Primary Page Layout
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->

 <div class="container">
    <div class="row">
      <div class="one-third column wide">
        <div class="boxes">
          <div class="headerpull">
		  
          <h4>	  <?php
		if(isset($_GET['Message'])){
    echo $_GET['Message'];
}
?> 
	
	</h4>
		
        </div>
		
		
  <!-- End Document
  –––––––––––––––––––––––––––––––––––––––––––––––––– -->
</body>

</html>
