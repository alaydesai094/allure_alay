<!DOCTYPE html>
<html>
<head>
</head>
<body>
<?php include 'config.php';?>
	<?php include 'header.php';?>
 
 <?php


$nights = $_POST["nights"];
$guests = $_POST["guests"];
$room_id = $_POST["id"];
$email = $_SESSION['email'];
$total = $_POST["total"];


?>



<div class="container">
    <div class="row">
      <div class="one-third column wide">
        <div class="boxes">
          <div class="headerpull">
          <h4>Book your room</h4>
         </div>
         <form action="booking_process.php" METHOD="POST">
		  
            <div class="row pullright">
              <div class="six columns">
                <label for="exampleEmailInput">Phone number</label>
                <input class="u-full-width" type="phone" id="phone" name= "phone" placeholder="Enter your phone" >
              </div>
			  </div>
			  <div class="row pullright">
              <div class="six columns">
                <label for="exampleEmailInput">Credit card number</label>
                <input class="u-full-width" type="cc" id="cc" name= "cc" placeholder="Enter your credit card number">
              </div>
			  </div>
            <div class="row pullright">
			<input class="u-full-width" type="hidden" id="total" name= "total" value="<?php echo $total; ?>">
			<input class="u-full-width" type="hidden" id="nights" name= "nights" value="<?php echo $nights; ?>">
			<input class="u-full-width" type="hidden" id="guests" name= "guests" value="<?php echo $guests; ?>">
			<input class="u-full-width" type="hidden" id="room_id" name= "room_id" value="<?php echo $room_id; ?>">
			<input class="u-full-width" type="hidden" id="email" name= "email" value="<?php echo $email; ?>">
              <input class="button-primary" id="button" type="submit" value="book">
            </div>
			
          </form>
        </div>
      </div>
    </div>
  </div>

</body>
</html>