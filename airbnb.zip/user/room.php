<!DOCTYPE html>
<html lang="en">

<body>
	<?php include 'config.php';?>
	<?php include 'header.php';?>
<?php
    // 1. Get the data from the form url
     $id =  $_GET["id"];
	 //echo "<strong> Showing Data For : </strong> ";
	 //echo $id; 
// Insert data into the db
    $sql = "SELECT * FROM room_data WHERE ID = '".$id."' ";
    $results = mysqli_query($conn, $sql);
	$x = mysqli_fetch_assoc($results);
		   ?>
		   
		
  <div id="container1">
  			  <div id="movementDown">
    				<h4><?php echo substr($x["Name"],0,200) . "..."  ;  ?></h4>
  				</div>
    		<div>
	  	<div class="bottomSpace sizechange">
         	 <span>
            		<img src="images/airbnbfavicon.png">
          		</span>
          			<span>
            			<strong><?php echo $x["Owner"];?> </strong>
			<br/> <p> <?php echo $x["Type"] ; ?> - <?php echo $x["Location"] ; ?>
			<br/><p> 
            <?php echo $x["Number of Reviews"];?> Reviews
            <?php

                $countStars = 0;
                for ($i=1; $i <= $x["Rating"] ; $i++) {

                    echo '<i class="fas fa-star"></i>';
                    $countStars++;
                }

                if (floor($x["Rating"])!=round($x["Rating"])) {
                    echo '<i class="fas fa-star-half-alt"></i>';
                    $countStars++;
                }
                for ($j=$countStars; $j < 5 ; $j++) {

                    echo '<i class="far fa-star"></i>';
                }

             ?></p>
			
          </span>
        </div>
     
        <p>
              <i class="fas fa-user-friends icon-space"></i> <?php echo $x["Guests"];?> guests
              <i class="fas fa-door-open icon-space"></i> <?php echo $x["Bedrooms"];?> bedrooms
              <i class="fas fa-bed icon-space"></i> <?php echo $x["Beds"];?> beds
              <i class="fas fa-bath icon-space"></i> <?php echo $x["Bath"];?> baths</p>
      </p>
	  	<p>	<?php echo $x["Description"];?> </p>
		<p><strong>Amenities</strong></p>
            <?php
            if ($x["Wifi"] == "yes") {
                echo '<p><i class="fas fa-wifi"></i> Wifi </p>';
            }
            if ($x["Free Parking"] == "yes") {
                echo '<p><i class="fas fa-parking"></i> Free parking on premises </p>';
            }
            if ($x["Kitchen"] == "yes") {
                echo '<p><i class="fas fa-utensils"></i> Kitchen </p>';
            }
			
			
            if ($x["Cable TV"] == "yes") {
                echo '<p><i class="fas fa-tv"></i> Cable TV </p>';
            }
            if ($x["Laundry"] == "yes") {
                echo '<p><i class="fas fa-thermometer-empty"></i> Laundry </p>';
            }
            if ($x["Laptop friendly"] == "yes") {
                echo '<p><i class="fas fa-laptop"></i>Laptop friendly workspace</p>';
            }
            ?>
			
	
  
  	<?php include 'footer.php';?>
  
</body>

</html>
