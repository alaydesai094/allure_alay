<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>AirBNB</title>
  <link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">
  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" href="css/navigation.css">
  <link rel="icon" type="image/png" href="images/airbnbfavicon.png">
 <script defer src="https://use.fontawesome.com/releases/v5.1.0/js/all.js"></script>

  <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
<script>
function goBack() {
    window.history.back();
}
</script>
</head>

<body>
<?php include 'config.php';
if(isset($_SESSION['email']))
	{
	} 
	else
	{
	 session_start();
	}
?>	
<div class="band navigation">
      <nav class="container primary">
          <div class="six columns">
              <ul class="navbar-right">
                  <li><strong><a href="home.php"><img  src="../images/logo.png"style="height:50px; width:160px"> </a></strong></li>
                  <li><a href="#">Help</a><?php if(isset($_SESSION['email']))
				  {
				  echo '<a href="logout.php">Logout</a>';
				  }else
				   { 
				   echo '<a href="login.php">Login</a>';
				   echo '<a href="signup.php">Sign Up</a>';
				    }?>
				  </li>
                  <li><a href="#"></a></li>
                  <li><a href="#"><?php 
												if(isset($_SESSION['email']))
												{ 
												$user = $_SESSION['email'];
												 echo "welcome : ".$user; 
												 }
										 else {
										  echo "welcome : User";
										   }?></a></li>
					 <li><a href="roombook.php"><?php
					 							 
												if(isset($_GET['id']))
												{ 
												$id= $_GET['id'];
												 echo '<a href="roombook.php?id='.$id.' ">Book Now</a> ';
												 }
										 else {
										   }?></a></li>
              </ul>
          </div>
		  <!-- Start of LiveChat (www.livechatinc.com) code -->
<script type="text/javascript">
window.__lc = window.__lc || {};
window.__lc.license = 10214972;
(function() {
  var lc = document.createElement('script'); lc.type = 'text/javascript'; lc.async = true;
  lc.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'cdn.livechatinc.com/tracking.js';
  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(lc, s);
})();
</script>
<noscript>
<a href="https://www.livechatinc.com/chat-with/10214972/">Chat with us</a>,
powered by <a href="https://www.livechatinc.com/?welcome" rel="noopener" target="_blank">LiveChat</a>
</noscript>
<!-- End of LiveChat code -->
      </nav>
  </div>
  
  
  
  
</body>

</html>
