<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>AirBNB</title>
  <link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">
  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" href="css/navigation.css">
  <link rel="icon" type="image/png" href="images/airbnbfavicon.png">

  <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
</head>

<body>
<?php include 'config.php';
if(isset($_SESSION['email']))
	{
	} 
	else
	{
	 session_start();
	}
?>	
<div class="band navigation">
      <nav class="container primary">
          <div class="six columns">
              <ul class="navbar-right">
                  <li><strong><a href="index.php"><img  src="../images/logo.png"style="height:50px; width:160px"> </a></strong></li>
                  <li><a href="#">Help</a><?php if(isset($_SESSION['email']))
				  {
				  echo '<a href="logout.php">Logout</a>';
				  }else
				   { 
				   echo '<a href="login.php">Login</a>';
				   echo '<a href="signup.php">Sign Up</a>';
				    }?>
				  </li>
                  <li><a href="#"></a></li>
                  <li><a href="#"><?php 
												if(isset($_SESSION['email']))
												{ 
												$user = $_SESSION['email'];
												 echo "welcome : ".$user; 
												 }
										 else {
										  echo "welcome : User";
										   }?></a></li>
              </ul>
          </div>
      </nav>
  </div>
</body>

</html>
