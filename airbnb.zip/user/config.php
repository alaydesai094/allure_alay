<?php

  // 1. connect to DATABASE
  $dbhost = "localhost";		// address of your database
  $dbuser = "root";					// database username
  $dbpassword = "";					// database password: on MAMP, this is "root"
  $dbname = "airbnb";							// @TODO: database name
  
  $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
 
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//echo "Connected successfully";

?>