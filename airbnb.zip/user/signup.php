<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>AirBNB</title>
  <link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/skeleton.css">
  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" href="css/navigation.css">
  <link rel="icon" type="image/png" href="images/airbnbfavicon.png">

  <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
</head>

<body>
	<?php include 'config.php';?>
	<?php include 'header.php';?>
<div class="container">
    <div class="row">
      <div class="one-third column wide">
        <div class="boxes">
          <div class="headerpull">
          <h4>Signup</h4>
          </div>
         
		  <form action="signup_process.php" METHOD="POST">
		  
            <div class="row pullright">
              <div class="six columns">
                <label for="exampleEmailInput">Email</label>
                <input class="u-full-width" type="email" id="email" name= "email" placeholder="Enter your email">
              </div>
			  </div>
			  <div class="row pullright">
              <div class="six columns">
                <label for="exampleEmailInput">Password</label>
                <input class="u-full-width" type="password"  id="password" name="password" placeholder="Enter your password" >
              </div>
            </div>
			<div class="row pullright">
              <div class="six columns">
                <label for="exampleEmailInput">First name</label>
                <input class="u-full-width" type="fname" id="fname" name= "fname" placeholder="Enter your first name">
              </div>
			  </div>
			  <div class="row pullright">
              <div class="six columns">
                <label for="exampleEmailInput">Last name</label>
                <input class="u-full-width" type="lname" id="lname" name= "lname" placeholder="Enter your last name">
              </div>
			  </div>
            <div class="row pullright">
              <input class="button-primary" id="button" type="submit" value="signup">
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

</body>

</html>
