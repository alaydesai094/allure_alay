<!DOCTYPE html>
<html>
<head>
<title>Final Test</title>
	 <link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css" rel="stylesheet" type="text/css" />
	 <link rel="stylesheet" href="final.css">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	 	<script src="https://use.fontawesome.com/7ffe815bc9.js"></script>
	 <link rel="stylesheet" type="text/css" href="admin.css">
	  <script type="text/javascript" src="admin.js"></script>


</head>
<body>
	<?php include 'header.php';?>
 
 <?php

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. Get the data from the form
     $email =  $_POST["email"];
	 echo $email; 
	 $password =  $_POST["password"];
	 echo $password; 
	  $fname =  $_POST["fname"];
	  echo $fname;
	   $lname =  $_POST["lname"];
	   echo $lname;

    // Insert data into the db
    $sql  =   "INSERT INTO user_data (email,password,fname,lname) 
		VALUES "
            . '("'
            . $email
            . '","'
            . $password
            . '","'
            . $fname
            . '","'
            . $lname
            . '")';



// VALUES (' " .$email." ',' " .$password." ',' " .$fname." ', ' " .$lname." '); 


    $results = mysqli_query($conn, $sql);

    // 4. If successful, redirect user to previous page
    if ($results) {
      header("Location: user.php");
    }
    // 5. If failure, show an error message
    else {
      echo "An error occured while saving your data.";
    }

  }

?>

 
 
 
 
  <!--- Data Show--->
  
  <div class="column" style=" width:90% ;overflow: auto; white-space: nowrap;" >
  <div class="tile is-parent" >
    <div class="tile is-child box">
	
	<form action="adduser.php" method="POST">
	
	  <div class="notification" style="width:809px ; margin-top:60px; margin-left:100px" >
   <label class="label" style="font-size:20px; margin-bottom:30px"><center>Add New Item </center></label>

<div class="field is-grouped" >

<div class="field" >
  <label class="label">Email</label>
  <div class="control">
    <input class="input" type="text" id="email" name="email" placeholder="Text input">
  </div>
</div>
<div class="field" >
  <label class="label">Password</label>
  <div class="control">
    <input class="input" type="text" id="password" name="password" placeholder="Text input">
  </div>
</div>

</div>

<div class="field is-grouped" >

<div class="field" >
  <label class="label">First Name</label>
  <div class="control">
    <input class="input" type="text" id="fname" name="fname" placeholder="Text input">
  </div>
</div>

<div class="field" >
  <label class="label">lname</label>
  <div class="control">
    <input class="input" type="text" id="lname" name="lname" placeholder="Text input">
  </div>
</div>

</div>

<div class="field is-grouped">
  <div class="control">
    <button class="button is-primary is-rounded" id ="Save">Save</button>
  </div>
  <div class="control">
    <button type="reset" class="button is-danger is-rounded">Cancel</button>
  </div>
</div>

 </div>
</form>
	      
    </div>
  </div>
</div>

  
  </div>
</div>
 <script type="text/javascript" src="admin.js"></script>

</div> <!---Cointainer--->
</body>
</html>