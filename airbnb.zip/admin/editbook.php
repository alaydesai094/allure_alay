<!DOCTYPE html>
<html>
<head>
<title>Final Test</title>
	 <link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css" rel="stylesheet" type="text/css" />
	 <link rel="stylesheet" href="final.css">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	 	<script src="https://use.fontawesome.com/7ffe815bc9.js"></script>
	 <link rel="stylesheet" type="text/css" href="admin.css">
	  <script type="text/javascript" src="admin.js"></script>


</head>
<body>
	<?php include 'header.php';?>
 
 <?php

  if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // 1. Get the data from the form url
     $pos =  $_GET["pos"];
	 echo $pos; 
// Insert data into the db
    $sql = "SELECT * FROM book_data WHERE ID = '".$pos."' ";
    $results = mysqli_query($conn, $sql);
	$x = mysqli_fetch_assoc($results);


?> 
  <!--- Data Show--->
  
  <div class="column" style=" width:90% ;overflow: auto; white-space: nowrap;" >
  <div class="tile is-parent" >
    <div class="tile is-child box">
	
	<form action="editbook.php" method="POST">
	
	  <div class="notification" style="width:809px ; margin-top:60px; margin-left:100px" >
   <label class="label" style="font-size:20px; margin-bottom:30px"><center>Add New Item </center></label>
<div class="field" >
  <label class="label">Email</label>
  <div class="control">
    <input class="input" type="text" id="email" name="email" value="<?php echo $x["email"]; ?>">
  </div>
</div>
<br>

<div class="field" >
  <label class="label">Room ID</label>
  <div class="control">
    <input class="input" type="text" id="room_id" name="room_id" value="<?php echo $x["room_id"] ; ?>">
  </div>
</div> 

<div class="field" >
  <label class="label">Nights</label>
  <div class="control">
    <input class="input" type="text" id="nights" name="nights" value="<?php echo $x["nights"] ; ?>">
  </div>
</div>

<div class="field" >
  <label class="label">Guests</label>
  <div class="control">
    <input class="input" type="text" id="guests" name="guests" value="<?php echo $x["guests"] ; ?>">
  </div>
</div>

<div class="field" >
  <label class="label">Amount</label>
  <div class="control">
    <input class="input" type="text" id="amount" name="amount" value="<?php echo $x["amount"] ; ?>">
  </div>
</div> 

<div class="field" >
  <label class="label">Phone</label>
  <div class="control">
    <input class="input" type="text" id="phone" name="phone" value="<?php echo $x["phone"] ; ?>">
  </div>
</div> 
</div>

<div class="field" >
  <label class="label"></label>
  <div class="control">
    <input class="input" type="hidden" id="id" name="id" value="<?php echo $x["id"] ; ?>">
  </div>
</div>

<div class="field is-grouped">
  <div class="control">
    <button class="button is-primary is-rounded" name="Save" id ="Save">Save</button>
  </div>
  <div class="control">
    <button type="reset" class="button is-danger is-rounded" onclick="user.php">Cancel</button>
  </div>
</div>

 </div>
</form>
<?php
  }

?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. Get the data from the form
  
     $id =  $_POST["id"];
	 echo $id;
	 $email =  $_POST["email"];
	 echo $id;
	 $room_id =  $_POST["room_id"];
	 echo $room_id;
	 $nights =  $_POST["nights"];
	 echo $nights;
	 $guests =  $_POST["guests"];
	 echo $guests;
		
$sql= "update book_data set email='$email', room_id='$room_id', nights='$nights',guests='$guests' where id= '$id'  ";
	
	// Execute query
	   $results = mysqli_query($conn, $sql);
	if($results)
	{
		echo "Updated";
	header('location:book.php'); 
	}
	else
	{
		echo "Not Updated";
	}
		
		
		
}
?>





	      
    </div>
  </div>
</div>

  
  </div>
</div>
 <script type="text/javascript" src="admin.js"></script>

</div> <!---Cointainer--->
</body>
</html>s