<!DOCTYPE html>
<html>
<head>
<title>Final Test</title>
	 <link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css" rel="stylesheet" type="text/css" />
	 <link rel="stylesheet" href="final.css">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	 	<script src="https://use.fontawesome.com/7ffe815bc9.js"></script>
	 <link rel="stylesheet" type="text/css" href="admin.css">
	  <script type="text/javascript" src="admin.js"></script>


</head>
<body>
	<?php include 'header.php';?>
	
		<?php    session_destroy();?>
 
  <!--- Data Show--->
  
  <div class="column" style=" width:90% ;overflow: auto; white-space: nowrap;" >
  <div class="tile is-parent" >
    <div class="tile is-child box">
	
	<form action="login_process.php" method="POST">
	
	  <div class="notification" style="width:809px ; margin-top:60px; margin-left:100px" >
   <label class="label" style="font-size:20px; margin-bottom:30px">Login </label>
    <label class="label"><?php
		if(isset($_GET['Message'])){
    echo $_GET['Message'];
}
?> </label>

<br><br>
   

<div class="field is-grouped" >

<div class="field" >
  <label class="label">Email</label>
  <div class="control">
    <input class="input" type="text" id="email" name="email" placeholder="Text input">
  </div>
</div>
<div class="field" >
  <label class="label">Password</label>
  <div class="control">
    <input class="input" type="text" id="password" name="password" placeholder="Text input">
  </div>
</div>

</div>

<div class="field is-grouped">
  <div class="control">
    <button class="button is-primary is-rounded" id ="Save">Login</button>
  </div>
</div>

 </div>
</form>
	      
    </div>
  </div>
</div>

  
  </div>
</div>
 <script type="text/javascript" src="admin.js"></script>

</div> <!---Cointainer--->
</body>
</html>