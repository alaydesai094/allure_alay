<!DOCTYPE html>
<html>
<head>
<title>Final Test</title>
	 <link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css" rel="stylesheet" type="text/css" />
	 <link rel="stylesheet" href="final.css">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	 	<script src="https://use.fontawesome.com/7ffe815bc9.js"></script>
	 <link rel="stylesheet" type="text/css" href="admin.css">
	  <script type="text/javascript" src="admin.js"></script>
	  
	</head>  
	<body>
	<?php include 'header.php';?>
	
	<?php
		$sql = 'SELECT * FROM book_data ';
 		$results = mysqli_query($conn, $sql);
		$rows = mysqli_num_rows($results);	
	
	?>
	
  <!--- Data Show--->
  
  <div class="column" >
  <div class="tile is-parent" >
    <div class="tile is-child box">
	
	<nav class="level">
  <!-- Left side -->
  <div class="level-left">
    <div class="level-item">
      		<p class="level-item">Total <?php echo "$rows";  ?> Entries Found </p> 
    </div>
  </div>
    <div class="level-right">
	  <p class="level-item"><a  href="adduser.php"  >Add New user </a></p>
  </div>
</nav>
	
	
			<!--- Table Content --->
	  <table class="table">
  <thead>
    <tr>
     <th name="id">ID</th>
      <th name="email">Email</th>
	   <th name="room_id">Room ID</th>
		<th name="nights">Nights</th>
		<th name="guests">Guests</th>
		<th name="amount">Amount</th>
		<th name="phone">Phone</th>
		<th name="edit">Edit</th>
		<th name="delete">Delete</th>
    </tr>
  </thead>
  
  <?php
 while( $x = mysqli_fetch_assoc($results) ) {
?>
  <tbody>
    <tr>
      <th><?php echo $x["id"] ; ?> </th>
      <td><?php echo $x["email"] ;  ?> </td>
      <td><?php echo $x["room_id"] ; ?></td>
      <td><?php echo $x["nights"]; ?></td>
      <td><?php echo $x["guests"]; ?></td>
	  <td><?php echo $x["amount"]; ?></td>
      <td><?php echo $x["phone"]; ?></td>
     
		<td><?php   echo '<a href="editbook.php?pos='.$x["id"].'">Edit</a> ';?></td>
		 <td><?php   echo '<a href="deletebook.php?pos='.$x["id"].'">Delete</a> ';?></td>
									
									<?php
       
      }
?>

    </tr>

  </tbody>
</table>
	      
    </div>
  </div>
</div>

  
  </div>
</div>
 <script type="text/javascript" src="admin.js"></script>

</div> <!---Cointainer--->
</body>
</html>