<!DOCTYPE html>
<html>
<head>
<title>Final Test</title>
	 <link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css" rel="stylesheet" type="text/css" />
	 <link rel="stylesheet" href="final.css">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	 	<script src="https://use.fontawesome.com/7ffe815bc9.js"></script>
	 <link rel="stylesheet" type="text/css" href="admin.css">
	  <script type="text/javascript" src="admin.js"></script>


</head>
<body>
	<?php include 'header.php';?>
 
 <?php

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. Get the data from the form
     $Name =  $_POST["Name"];
	 echo $Name; 
	 $Type =  $_POST["Type"];
	 echo $Type; 
	  $Location =  $_POST["Location"];
	  echo $Location;
	   $Price =  $_POST["Price"];
	   echo $Price;
	    $Rating =  $_POST["Rating"];
		echo $Rating;
		 $Number_of_Reviews =  $_POST["Number_of_Reviews"];
		 echo $Number_of_Reviews;
		 $Superhost =  $_POST["Superhost"];
		 echo $Superhost;
  		$Owner =  $_POST["Owner"];
		echo $Owner;
    		$Guests =  $_POST["Guests"];
		echo $Guests; 
    		$Bedrooms =  $_POST["Bedrooms"];
		echo $Bedrooms; 
	 	$Beds =  $_POST["Beds"];
		echo $Beds;
	  	$Bath =  $_POST["Bath"];
		echo $Bath; 
	   	$Free_Cancellation =  $_POST["Free_Cancellation"];
		echo $Free_Cancellation;
	    $Description =  $_POST["Description"];
		echo $Description;
		$Free_Parking =  $_POST["Free_Parking"];
		echo $Free_Parking;
		$Laptop_Friendly  =  $_POST["Laptop_Friendly"];
		echo $Laptop_Friendly;
		$Laundry =  $_POST["Laundry"];
		echo $Laundry ;
		$Wifi =  $_POST["Wifi"];
		echo $Wifi;
		$Kitchen =  $_POST["Kitchen"];
		echo $Kitchen; 
		$Cable_TV =  $_POST["Cable_TV"];	
		echo $Cable_TV;

    // Insert data into the db
    $sql  =   "INSERT INTO room_data (
Name,
Type,
Location,
Price, 
Rating,
Number of Reviews,
Superhost,
Owner,
Guests,
Bedrooms,
Beds,
Bath,
Free Cancellation,
Description,
Free Parking,
Laptop friendly,
Laundry,
Wifi,
Kitchen,
Cable TV) 

VALUES "
            . '("'
            . $Name
            . '","'
            . $Type
            . '","'
            . $Location
            . '","'
            . $Price
            . '","'
            .$Rating
			  . '","'
			  .$Number_of_Reviews
			  . '","'
			  .$Superhost
			  . '","'
			  .$Owner
			  . '","'
			  .$Guests
			  . '","'
			  .$Bedrooms
			  . '","'
			  .$Beds
			  . '","'
			  .$Bath
			  . '","'
			  .$Free_Cancellation
			  . '","'
			  .$Description
			  . '","'
			  .$Free_Parking
			  . '","'
			  .$Laptop_Friendly
			 	. '","'
				.$Laundry
				. '","'
				.$Wifi
				. '","'
				.$Kitchen
				. '","'
				.$Cable_TV 
            . '")';



/*
VALUES (' " .$Name." ', 
				' " .$Type." ',
				' " .$Location." ', 
				' " .$Price." ', 
				' " .$Rating." ', 
				' " .$Number_of_Reviews." ', 
				' " .$Superhost." ', 
				' " .$Owner." ', 
				' " .$Guests." ', 
				' " .$Bedrooms." ', 
				' " .$Beds." ', 
				' " .$Bath." ', 
				' " .$Free_Cancellation." ', 
				' " .$Description." ', 
				' " .$Free_Parking." ', 
				' " .$Laptop_Friendly." ',
				' " .$Laundry." ', 
				' " .$Wifi." ',
				' " .$Kitchen." ',
				' " .$Cable_TV." '
				 ) ";
*/
    $results = mysqli_query($conn, $sql);

    // 4. If successful, redirect user to previous page
    if ($results) {
      header("Location: additem.php");
    }
    // 5. If failure, show an error message
    else {
      echo "An error occured while saving your data.";
    }

  }

?>

 
 
 
 
  <!--- Data Show--->
  
  <div class="column" style=" width:90% ;overflow: auto; white-space: nowrap;" >
  <div class="tile is-parent" >
    <div class="tile is-child box">
	
	<form action="additem.php" method="POST">
	
	  <div class="notification" style="width:809px ; margin-top:60px; margin-left:100px" >
   <label class="label" style="font-size:20px; margin-bottom:30px"><center>Add New Item </center></label>
<div class="field" >
  <label class="label">Name</label>
  <div class="control">
    <input class="input" type="text" id="Name" name="Name" placeholder="Text input">
  </div>
</div>
<br>
<div class="field">
<label class="label">Type</label>
  <div class="control">
  <label class="radio">
    <input type="radio" name="Type" value ="Private Room">
    Private Room
  </label>
  <label class="radio">
    <input type="radio" name="Type" value= "Entire Loft">
   Entire Loft
  </label>
  </label>
  <label class="radio">
    <input type="radio" name="Type" value= "Entire Condominium">
   Entire Condominium
  </label>
  </label>
  <label class="radio">
    <input type="radio" name="Type" value= "Entire Apartment">
   Entire Apartment
  </label>
</div>
<br>
<div class="field is-grouped" >

<div class="field" >
  <label class="label">Location</label>
  <div class="control">
    <input class="input" type="text" id="Location" name="Location" placeholder="Text input">
  </div>
</div>
<div class="field" >
  <label class="label">Price</label>
  <div class="control">
    <input class="input" type="text" id="Price" name="Price" placeholder="Text input">
  </div>

</div>

<div class="field is-grouped" >

<div class="field" >
  <label class="label">Rating</label>
  <div class="control">
    <input class="input" type="text" id="Rating" name="Rating" placeholder="Text input">
  </div>
</div>
</div>
<div class="field" >
  <label class="label">Number of Reviews</label>
  <div class="control">
    <input class="input" type="text" id="Number_of_Reviews" name="Number_of_Reviews" placeholder="Text input">
  </div>
</div>

</div>

<div class="field" >
  <label class="label">Superhost</label>
  <div class="control">
    <input class="input" type="text" id="Superhost" name="Superhost" placeholder="Text input">
  </div>
</div>

<div class="field is-grouped" >

<div class="field" >
  <label class="label">Owner </label>
  <div class="control">
    <input class="input" type="text" id="Owner" name="Owner" placeholder="Text input">
  </div>
</div>

<div class="field" >
  <label class="label">Guests</label>
  <div class="control">
    <input class="input" type="text" id="Guests" name="Guests" placeholder="Text input">
  </div>
</div>

</div>

<div class="field is-grouped" >

<div class="field" >
  <label class="label">Bedrooms</label>
  <div class="control">
    <input class="input" type="text" id="Bedrooms" name="Bedrooms" placeholder="Text input">
  </div>
</div>

<div class="field" >
  <label class="label">Beds</label>
  <div class="control">
    <input class="input" type="text" id="Beds" name="Beds" placeholder="Text input">
  </div>
</div>

<div class="field" >
  <label class="label">Bath</label>
  <div class="control">
    <input class="input" type="text" id="Bath" name="Bath" placeholder="Text input">
  </div>
</div>

</div>

<div class="field is-grouped" >

<div class="field" >
  <label class="label">Free Cancellation </label>
  <div class="control">
    <input class="input" type="text" id="Free_Cancellation" name="Free_Cancellation" placeholder="Text input">
  </div>
</div> 

<div class="field" >
  <label class="label">Description</label>
  <div class="control">
    <input class="input" type="text" id="Description" name="Description" placeholder="Text input">
  </div>
</div> 

<div class="field" >
  <label class="label">Free Parking</label>
  <div class="control">
    <input class="input" type="text" id="Free_Parking" name="Free_Parking" placeholder="Text input">
  </div>
</div> 

</div>

<div class="field is-grouped" >

<div class="field" >
  <label class="label">Laptop Friendly</label>
  <div class="control">
    <input class="input" type="text" id="Laptop_Friendly" name="Laptop_Friendly" placeholder="Text input">
  </div>
</div> 

<div class="field" >
  <label class="label">Laundry</label>
  <div class="control">
    <input class="input" type="text" id="Laundry" name="Laundry" placeholder="Text input">
  </div>
</div> 

<div class="field" >
  <label class="label">Wifi</label>
  <div class="control">
    <input class="input" type="text" id="Wifi" name="Wifi" placeholder="Text input">
  </div>
</div>
 
<div class="field" >
  <label class="label">Kitchen</label>
  <div class="control">
    <input class="input" type="text" id="Kitchen" name="Kitchen" placeholder="Text input">
  </div>
</div> 

<div class="field" >
  <label class="label">Cable_TV</label>
  <div class="control">
    <input class="input" type="text" id="Cable_TV" name="Cable_TV" placeholder="Text input">
  </div>
</div> 

</div>

<div class="field is-grouped">
  <div class="control">
    <button class="button is-primary is-rounded" id ="Save">Save</button>
  </div>
  <div class="control">
    <button type="reset" class="button is-danger is-rounded">Cancel</button>
  </div>
</div>

 </div>
</form>
	      
    </div>
  </div>
</div>

  
  </div>
</div>
 <script type="text/javascript" src="admin.js"></script>

</div> <!---Cointainer--->
</body>
</html>