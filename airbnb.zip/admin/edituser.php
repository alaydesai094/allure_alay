<!DOCTYPE html>
<html>
<head>
<title>Final Test</title>
	 <link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css" rel="stylesheet" type="text/css" />
	 <link rel="stylesheet" href="final.css">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	 	<script src="https://use.fontawesome.com/7ffe815bc9.js"></script>
	 <link rel="stylesheet" type="text/css" href="admin.css">
	  <script type="text/javascript" src="admin.js"></script>


</head>
<body>
	<?php include 'header.php';?>
 
 <?php

  if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // 1. Get the data from the form url
     $pos =  $_GET["pos"];
	 echo $pos; 
// Insert data into the db
    $sql = "SELECT * FROM user_data WHERE ID = '".$pos."' ";
    $results = mysqli_query($conn, $sql);
	$x = mysqli_fetch_assoc($results);


?> 
  <!--- Data Show--->
  
  <div class="column" style=" width:90% ;overflow: auto; white-space: nowrap;" >
  <div class="tile is-parent" >
    <div class="tile is-child box">
	
	<form action="edituser.php" method="POST">
	
	  <div class="notification" style="width:809px ; margin-top:60px; margin-left:100px" >
   <label class="label" style="font-size:20px; margin-bottom:30px"><center>Add New Item </center></label>
<div class="field" >
  <label class="label">Email</label>
  <div class="control">
    <input class="input" type="text" id="email" name="email" value="<?php echo $x["email"]; ?>">
  </div>
</div>
<br>

<div class="field" >
  <label class="label">Password</label>
  <div class="control">
    <input class="input" type="text" id="password" name="password" value="<?php echo $x["password"] ; ?>">
  </div>
</div> 

<div class="field" >
  <label class="label">First Name</label>
  <div class="control">
    <input class="input" type="text" id="fname" name="fname" value="<?php echo $x["fname"] ; ?>">
  </div>
</div>
 
<div class="field" >
  <label class="label">Last Name</label>
  <div class="control">
    <input class="input" type="text" id="lname" name="lname" value="<?php echo $x["lname"] ; ?>">
  </div>
</div> 

</div>

<div class="field" >
  <label class="label"></label>
  <div class="control">
    <input class="input" type="hidden" id="id" name="id" value="<?php echo $x["id"] ; ?>">
  </div>
</div>

<div class="field is-grouped">
  <div class="control">
    <button class="button is-primary is-rounded" name="Save" id ="Save">Save</button>
  </div>
  <div class="control">
    <button type="reset" class="button is-danger is-rounded" onclick="user.php">Cancel</button>
  </div>
</div>

 </div>
</form>
<?php
  }

?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. Get the data from the form
  
     $id =  $_POST["id"];
	 //echo $ID; 
     $fname =  $_POST["fname"];
	 //echo $fname;
	  $lname =  $_POST["lname"];
	 //echo $lname; 
	  $email =  $_POST["email"];
	 //echo $email;
	  $password =  $_POST["password"];
	 //echo $password;  
		
$sql= "update user_data set email='$email', password='$password', fname='$fname',lname='$lname' where id= '$id'  ";
	
	// Execute query
	   $results = mysqli_query($conn, $sql);
	if($results)
	{
		echo "Updated";
		header('location:user.php'); 
	}
	else
	{
		echo "Not Updated";
	}
		
		
		
}
?>





	      
    </div>
  </div>
</div>

  
  </div>
</div>
 <script type="text/javascript" src="admin.js"></script>

</div> <!---Cointainer--->
</body>
</html>