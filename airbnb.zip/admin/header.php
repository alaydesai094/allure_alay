<!DOCTYPE html>
<html>
<head>
<title>Final Test</title>
	 <link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css" rel="stylesheet" type="text/css" />
	 <link rel="stylesheet" href="final.css">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	 	<script src="https://use.fontawesome.com/7ffe815bc9.js"></script>
	 <link rel="stylesheet" type="text/css" href="admin.css">
	  <script type="text/javascript" src="admin.js"></script>


<script>
//dropdown - sort option 
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>


</heaad>




<?php

  // 1. connect to DATABASE
  $dbhost = "localhost";		// address of your database
  $dbuser = "root";					// database username
  $dbpassword = "";					// database password: on MAMP, this is "root"
  $dbname = "airbnb";							// @TODO: database name
  
  $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
 
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//echo "Connected successfully";
?>

<?php
if(isset($_SESSION['email']))
	{
	} 
	else
	{
	 session_start();
	}
?>	

<body>
<div class="container">
  <div class="column" >
<!----Search bar--->
	<!-- Main container -->
<nav class="level">
  <!-- Left side -->
  <div class="level-left">
    <div class="level-item">
      <p class="subtitle is-5">
        <strong>  <a href="index.php"><img  src="logo.png" style="height:50px; width:90px"> </a></strong> 
		
    </div>
  </div>

  <!-- Right side -->
  <div class="level-right">
  
  <p class="level-item"><a href="#"><?php 
												if(isset($_SESSION['email']))
												{ 
												$user = $_SESSION['email'];
												 echo "welcome : ".$user; 
												 }
										 else {
										  echo "welcome : User";
										   }?></a></p>
      </p>
	
	   <?php if(isset($_SESSION['email']))
				  {
				  
				   echo '<p class="level-item"><a  href="home.php"  >Home</a></p>';
	  
	 echo ' <div class="dropdown">';
	echo '<button onclick="myFunction()"  class="dropbtn">Filter By</button>';
  	echo '<div id="myDropdown" class="dropdown-content">';
	  echo ' <a href="sort.php?sort=all">Show All</a>';
 echo '<a href="sort.php?sort=pr " >Private Rooms</a>';
   echo ' <a href="sort.php?sort=el">Entire Loft</a>';
    echo '<a href="sort.php?sort=ec">Entire Condominium</a>';
	 echo ' <a href="sort.php?sort=ea">Entire Apartment</a>';
echo '</div>';
echo '</div>';
	  
	  echo '<p class="level-item"><a  href="additem.php"  >Add New Data </a></p>';
	   echo '<p class="level-item"><a  href="user.php"  >Manage Users </a></p>';
	    echo '<p class="level-item"><a  href="book.php"  >Manage Booking  </a></p>';
	echo '<p class="level-item"><a class="button is-danger"  href="logout.php">Logout</a></p>';
				  
				 }
				 else
				   { 
				   echo ' <p class="level-item"><a class="button is-danger" href="index.php">Login</a></p>';
				   
				 
				    }?>
  </div>
</nav>

  </div>
  </div>
</div>
 <script type="text/javascript" src="admin.js"></script>

</div> <!---Cointainer--->
</body>
</html>