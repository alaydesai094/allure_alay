//
//  ViewController.swift
//  class3
//
//  Created by MacStudent on 2018-11-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var UserInput: UITextField!
    
     var context:NSManagedObjectContext!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Setup your CoreData variable
        // ----------------------------------------
        
        // 1. Mandatory - copy and paste this
        // Explanation: try to create/initalize the appDelegate variable.
        // If creation fails, then quit the app
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        
        // 2. Mandatory - initialize the context variable
        // This variable gives you access to the CoreData functions
        self.context = appDelegate.persistentContainer.viewContext
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func AddUser(_ sender: Any) {
       print("Add button pressed")
        print("Signup button pressed!")
        
        // Create the "row" you want to insert into the database
        // When using CoreData, you don't do a SQL statment
        // You create an OBJECT, and then insert the OBJECT
        
        // Below code is equivalent of:
        //      INSERT INTO User(email, password) VALUES ("michael@gmail.com", "1234")
        let P = Person(context: self.context)
        P.name = "Alay"
        P.age = 24
        
        do {
            // Save the user to the database
            // (Send the INSERT to the database)
            try self.context.save()
        }
        catch {
            print("Error while saving to database")
        }
        
        
       
    }
    
    
    @IBAction func LoadButton(_ sender: Any) {
    
        print("Show all Person pressed!")
        
        // This is the same as:  SELECT * FROM User
        let fetchRequest:NSFetchRequest<Person> = Person.fetchRequest()
        
        do {
            // Send the "SELECT *" to the database
            //  results = variable that stores any "rows" that come back from the db
            // Note: The database will send back an array of User objects
            // (this is why I explicilty cast results as [Person]
            let results = try fetchRequest.execute() as [Person]
            
            // Loop through the database results and output each "row" to the screen
            print("Number of items in database: \(results.count)")
            
            for x in results {
                print("User Email: \(x.name)")
                print("User Password: \(x.age)")
            }
        }
        catch {
            print("Error when fetching from database")
        }
    }

    
    
    }
    


