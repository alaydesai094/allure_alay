document.getElementById("rideButton").addEventListener("click",checkrideDetails);

function checkrideDetails() {
	
 var from = document.getElementById("from").value;
var to = document.getElementById("to").value;
 var pool = document.getElementById("pool").value;
 var direct = document.getElementById("direct").value;
	
if (from == "" && to =="")
{
alert("Please input a Value");
  console.log("Need some Input");
}
else 
{
alert('Code has accepted : you can try another');
	   console.log("Good to Go");
   console.log("From : " + from);
    console.log("To : " + to);
	
		if(document.getElementById("pool").checked) {
   					console.log(" Ryde : " + pool);
		}else if( document.getElementById("direct").checked) {
   					console.log("Ryde : " + direct );
		}	
}


}
